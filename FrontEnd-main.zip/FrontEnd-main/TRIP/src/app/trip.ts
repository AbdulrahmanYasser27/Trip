export class Trip {

    id = 0;
    from_station = "";
    to_station = "";
    departure_time = "";
    arrival_time = "";
}
