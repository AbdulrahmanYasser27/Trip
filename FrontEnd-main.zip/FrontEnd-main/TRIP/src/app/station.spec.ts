import { Station } from './station';

describe('Station', () => {
  it('should create an instance', () => {
    expect(new Station()).toBeTruthy();
  });
});
