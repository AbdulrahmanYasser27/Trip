export class Station {
    id!:number;
    name!:string;
}
