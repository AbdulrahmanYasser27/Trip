export class Admin {
    id!:number
    email!:string;
    admin_Name!:string;
    password!:string;

}

